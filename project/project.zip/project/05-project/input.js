var arr = [1,5,36,1,2,3];

var newArr =  arr.filter(function (item) {
  return item < 10
})

console.log(newArr);
