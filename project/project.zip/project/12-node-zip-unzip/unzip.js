var fs = require('fs');
var unzip = require('unzip');

fs.createReadStream('test.zip').pipe(unzip.Extract({path: 'unarchive'}));