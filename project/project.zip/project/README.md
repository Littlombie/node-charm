## 文件目录
```
├── 01-project ---------- 创建一个服务  
├── 02-project ---------- 阻塞 （读取文件）
├── 03-project ---------- 非阻塞
├── 04-project ---------- 事件驱动
├── 05-project ---------- Node 应用程序是如何工作的？
├── 06-project ---------- Node.js EventEmitter
├── 07-project ---------- eventEmitter
├── 08-project ---------- buffer
├── 09-project ---------- stream(流)
│   ├── main.js --------- 读取文件流
│   ├── main2.js -------- 写入文件流
├── 10-project ---------- 管道流 把一个文件的内容复制到另一个文件
├── 11-project ---------- 链式流 （文件压缩/解压）
```