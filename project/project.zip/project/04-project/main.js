// 引入events 模块
var events = require('events');

// 创建事件处理程序
var eventEmitter = new events.EventEmitter();

//创建事件处理程序
var connectHandler = function  connected() {
  console.log('链接成功');

  //触发 data_received 事件
  eventEmitter.emit('data_received', 'www');
}

//绑定 connection 事件处理程序
eventEmitter.on('connection', connectHandler);

// 使用匿名函数绑定data_receivrd事件
eventEmitter.on('data_received', function (e) {
  console.log('数据接收成功', e);
});

// 触发 connection 事件

eventEmitter.emit('connection');

console.log('程序执行完毕');