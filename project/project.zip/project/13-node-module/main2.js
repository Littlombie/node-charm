var Hello = require('./hello2');

hello = new Hello();

hello.setName('BYVoid');
hello.sayHello();
