var hello = require('./hello.js');
hello.world();