const chalk = require('chalk');

console.log(chalk.red('This is red'));