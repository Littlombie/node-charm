const {env} = process;

console.log(env);