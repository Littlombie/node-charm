const mod = require('./08_global');

console.log(mod.testVar);
console.log(testVal2);