const testVal = 1000;

global.testVal2 = 200;

module.exports.testVar = testVal;