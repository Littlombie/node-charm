const mod = require('./02cusmod');

console.log(mod.testVal);

mod.testFn()