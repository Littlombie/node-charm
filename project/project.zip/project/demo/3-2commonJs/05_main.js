
const modeA = require('./05_modA');

const modeB = require('./05_modB');

console.log(modeA.mod);

console.log(modeB.mod);

