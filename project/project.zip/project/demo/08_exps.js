// const exports = module.exports;

// (
//   function (exports, require, module, _filename, _dirname) {

//   }
// )

// exports.aaa = 100;

module.exports = {
  aaa: 100,
  bbb: 20,
  ccc: function () {
    console.log('ddd');
  }
}

