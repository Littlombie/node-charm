const m = require('./08_exps.js');

console.log(m.aaa);
m.ccc();