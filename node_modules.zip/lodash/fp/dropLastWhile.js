module.exports = require('./dropRightWhile');
