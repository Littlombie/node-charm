
# Changelog

## trunk

tests: remove references to coverage

## v1.1.0

* test: should require handled by mocha
* package: coffeescript 2 and use semver tilde
* options: validate column types, fix #4
